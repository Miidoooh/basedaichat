# NoChatUsername
Detect messages and delete automatically Public Chat username 


## Local Deployment Process
```sh
sudo apt update && apt upgrade -y
sudo apt install git curl python3-pip ffmpeg -y
git clone https://github.com/ITZ-ZAID/NoChatUsername ok
cd ok
pip3 install -U -r requirements.txt
python3 main.py # run the bot.
```
#
