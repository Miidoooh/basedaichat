from os import getenv

BOT_TOKEN = getenv("BOT_TOKEN", "5880966736:AAEbyHifSR8jy8uFmcvdactmzNZf8XpOSqQ")
